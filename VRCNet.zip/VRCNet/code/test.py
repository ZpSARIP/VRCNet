from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
from torch.autograd import Variable
import torch.backends.cudnn as cudnn
import torch.nn.parallel
import os, shutil, json
import argparse
import time
from torch.utils.data import ConcatDataset
from provider.ImgDataset import MultiviewImgDataset
from models.CorrRegResNet import resnet18,resnet101,resnet34,resnet50
from models.swin_transformer import swin_transformer_tiny
from models.convnext_crossC_pooling_5 import convnext_tiny
parser = argparse.ArgumentParser()
# parser.add_argument("-train_path", type=str, default="modelnet40_images_new_12x\\*\\train")
# parser.add_argument("-val_path", type=str, default="modelnet40_images_new_12x\\*\\test")
# parser.add_argument("-bs", "--batchSize", type=int, help="Batch size for the second stage",
#                     default=4)  # it will be *12 images in each batch for mvcnn
# parser.add_argument("-num_views", type=int, help="number of views", default=6)
parser.add_argument("-lr", type=float, help="learning rate", default=1e-4)
parser.add_argument("-weight_decay", type=float, help="weight decay", default=1e-4)
# parser.add_argument('--epochs', default=20, type=int, metavar='N',
#                     help='number of total epochs to run (default: 100)')
parser.add_argument('--momentum', default=0.9, type=float, metavar='M',
                    help='momentum (default: 0.9)')
parser.add_argument('--lr-decay-freq', default=30, type=float,
                    metavar='W', help='learning rate decay (default: 30)')
parser.add_argument('--lr-decay', default=0.1, type=float,
                    metavar='W', help='learning rate decay (default: 0.1)')
parser.add_argument('--lamda', default=0.0005, type=float,
                    metavar='W', help='lamda')
parser.add_argument('--print-freq', '-p', default=10, type=int,
                    metavar='N', help='print frequency (default: 10)')
parser.add_argument('-r', '--resume', default='', type=str, metavar='PATH',
                    help='path to latest checkpoint (default: none)')
parser.add_argument("-no_pretraining", dest='no_pretraining', action='store_true')

parser.set_defaults(train=False)
args = parser.parse_args()



def test(val_loader, model, criterion):
    batch_time = AverageMeter()
    losses = AverageMeter()
    top1 = AverageMeter()
    model.eval()

    inputs_val = Variable(torch.FloatTensor(1).cuda())
    targets_val = Variable(torch.LongTensor(1).cuda())

    end = time.time()
    for i, (inputs, targets) in enumerate(val_loader):
        inputs_val.resize_(inputs.size()).copy_(inputs)
        targets_val.resize_(targets.size()).copy_(targets)
        output = model(inputs_val)
        # print(output)
        loss = criterion(output, targets_val)

        prec = accuracy(output.data, targets_val.data)
        losses.update(loss.item(), inputs.size(0))
        top1.update(prec, inputs.size(0))

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        if i % args.print_freq == 0:
            print('Test: [{0}/{1}]\t'
                  'Time {batch_time.val:.3f} ({batch_time.avg:.3f})\t'
                  'Loss {loss.val:.4f} ({loss.avg:.4f})\t'
                  'Prec@1 {top1.val:.3f} ({top1.avg:.3f})\t'.format(
                i, len(val_loader), batch_time=batch_time, loss=losses, top1=top1))


    return top1.avg




class AverageMeter(object):
    """Computes and stores the average and current value"""

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def accuracy(output, target):
    """Computes the precision@k for the specified values of k"""
    batch_size = target.size(0)
    _, pred = torch.max(output, 1)

    pred = pred.view(-1)
    target = target.view(-1)
    correct = torch.sum(pred.eq(target))

    return 100 * correct / float(batch_size)


if __name__ == '__main__':

    pretraining = not args.no_pretraining


    # test_dataset1 = MultiviewImgDataset("F:\\tangyijun\\切片3月\\切片3月\\切片3月\\class15\\*\\train", scale_aug=False, rot_aug=False,
    #                                    num_views=6)
    # test_dataset2 = MultiviewImgDataset("F:\\tangyijun\\切片3月\\切片3月\\切片3月\\class31\\*\\train", scale_aug=False,
    #                                     rot_aug=False,
    #                                     num_views=6)
    # test_dataset3 = MultiviewImgDataset("F:\\tangyijun\\切片3月\\切片3月\\切片3月\\class45\\*\\train", scale_aug=False,
    #                                     rot_aug=False,
    #                                     num_views=6)



    # test_dataset =  MultiviewImgDataset("F:\\tangyijun\\testdata\\testdata\\CorrRegResNet\\random_group\\random_group\\*\\test", scale_aug=False,
    #                                     rot_aug=False,
    #                                     num_views=6)
    test_dataset = MultiviewImgDataset(

        # "D:\\zhoupeng\\Recognition\\dataset\\7_balance\\test\\5views\\all\\*\\test", scale_aug = False,rot_aug = False,num_views =5)
        "D:\\zhoupeng\\Recognition\\dataset\\Bistatic\\all\\5views1\\*\\test", scale_aug = False,rot_aug = False,num_views =5)

    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=4)
    # test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=8, shuffle=False, num_workers=0)

    print('num_test_files: ' + str(len( test_dataset)))
    # print('num_val_files: ' + str(len(val_dataset.filepaths)))
    # model = convnext_tiny(pretrained=False, num_classes=9, layer_scale_init_value=1e-6, head_init_scale=1.0)
    model = convnext_tiny(pretrained=False, view_nums=5, num_classes=9, layer_scale_init_value=1e-6, head_init_scale=1.0)

    # model = swin_transformer_tiny(input_shape=[224, 224], pretrained=True, num_classes=9)

    # model = resnet50(pretrained=pretraining, num_classes=9, lamda=args.lamda)
    model = torch.nn.DataParallel(model,device_ids=[0,1]).cuda()
    # model = torch.nn.DataParallel(model).cuda()

    criterion = nn.CrossEntropyLoss().cuda()
    optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay, betas=(0.9, 0.999))

    path = r"D:\zhoupeng\Recognition\MvFusionNet-pytorch\logs\epoch_4\model_best.pth.tar"
    # path = r"D:\zhoupeng\Recognition\MvFusionNet-pytorch\logs\epoch_1\model_best.pth.tar"
    # path = r"D:\zhoupeng\Recognition\MvFusionNet-pytorch\logs_师弟\model_best.pth.tar"
    # if args.resume:
    #     if os.path.isfile(args.resume):
    print("=> loading checkpoint '{}'".format(path))
    checkpoint = torch.load(path)
    start_epoch = checkpoint['epoch']
    best_prec = checkpoint['best_prec']
    model.load_state_dict(checkpoint['state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer'])
    print("=> loaded checkpoint '{}' (epoch {})"
          .format(path, checkpoint['epoch']))

    prec = test(test_loader, model, criterion)
    print('Test acc:{}'.format(prec))



    print('Fisished!')
